# DVD2025GP-DataWizards

start up command : ```streamlit run loan_risk_dashboard.py```

Note: the data is not part of the repo considering the size constraints
